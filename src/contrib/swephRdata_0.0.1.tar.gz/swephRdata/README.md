# swephRdata
Data files for swephR
