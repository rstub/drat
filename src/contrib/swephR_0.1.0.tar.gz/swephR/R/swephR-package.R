##' @useDynLib swephR, .registration = TRUE
##' @importFrom Rcpp evalCpp
"_PACKAGE"
