#' Constants used in swephR
#'
#'
#' \itemize{
#'   \item name of variable
#'   \item value of the variable
#' }
#'
#' @docType data
#' @keywords datasets
#' @name SE
#' @usage data(SE)
#' @format A data frame with 217 rows and 2 variables
NULL