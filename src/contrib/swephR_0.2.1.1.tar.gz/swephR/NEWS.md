# NEWS for swephR

## swephR 0.2.1

* fix stack overflow write in libswe

## swephR 0.2.0

* new upstream version v2.08
* support for more functions from SE's C API

## swephR 0.1.5

* Fixed compilation problems on Solaris for real

## swephR 0.1.4

* removed compilation warnings and errors on Solaris
* fixed a buffer underflow error

## swephR 0.1.3

* Initial CRAN release
