# saveRDS(c("BCE", "Ephemeris", "JPL", "Moshier", "ephemerides", "ephemeris", "repos", "swephRdata"), file="swephR.rds")
Rd_files <- vignettes <- R_files <- description <-
    list(encoding = "UTF-8",
         language = "en",
         dictionaries = c("en_stats", "swephR"))
