library(testthat)
library(swephR)

test_check("swephR")
