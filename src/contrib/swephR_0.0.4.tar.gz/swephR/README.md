  [![Travis build status](https://travis-ci.org/rstub/swephR.svg?branch=master)](https://travis-ci.org/rstub/swephR)
  [![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/rstub/swephR?branch=master&svg=true)](https://ci.appveyor.com/project/rstub/swephR)
  [![Coverage status](https://codecov.io/gh/rstub/swephR/branch/master/graph/badge.svg)](https://codecov.io/github/rstub/swephR?branch=master)

# swephR
High Precision Swiss Ephemeris

# Installation
Since `swephR` is not on CRAN, you have to install from GitHub

```
remotes::install_github("rstub/swephR")
```